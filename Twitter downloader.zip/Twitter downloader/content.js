// content.js
const wait_time = 500;

// 定义一个函数download_img, 用于根据传入的图片地址（src）和文件名（filename）下载单个图片
// 使用XMLHttpRequest发起GET请求, 成功后生成一个URL并触发下载
function download_img(src, filename) {
    var req = new XMLHttpRequest();
    // console.log('正在连接url...');
    req.open("GET", src, true);
    // console.log('连接成功');
    req.responseType = 'blob';
    req.onload = function (e) {
        if (navigator.msSaveBlob) {
            var name = resourceUrl.substr(resourceUrl.lastIndexOf("/") + 1);
            return navigator.msSaveBlob(req.response, name);
        } else {
            var url = window.URL.createObjectURL(req.response);
            var a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.click();
        }
    }
    return req.send();
}

// 定义一个函数download_imgs, 用于根据传入的图片数组(images)、日期(date)和内容(content)下载多个图片
// 通过正则表达式替换获取原图链接, 格式化日期时间, 并生成文件名调用download_img函数进行下载
function download_imgs(images, date, content) {
    // 格式化日期时间字符串
    const dateTimeFormatted = date.replace('T', ' ').replace(/:/g, '').replace(/\.\d+Z$/, '');
    const max_str = 60;
    if (content.length > max_str) {
        content = content.substring(0, max_str);
    }

    images.forEach((src, index) => {
        // 替换src中的格式参数，获取原图链接
        const srcOriginal = src.replace(/format=jpg&name=\w+/, 'format=jpg&name=orig');

        let filename = '';
        if (content === '') {
            filename = images.length === 1 ? `${dateTimeFormatted}.jpeg` : `${dateTimeFormatted} ${index + 1}.jpeg`;
        } else {
            filename = images.length === 1 ? `${dateTimeFormatted} ${content}.jpeg` : `${dateTimeFormatted} ${content} ${index + 1}.jpeg`;
        }

        // 调用download_img函数下载图片
        download_img(srcOriginal, filename);
    });
}

// 定义一个函数auto_download, 用于根据传入的CSS选择器找到图片并模拟点击, 然后调用auto_process函数进行处理
function auto_download(css) {
    const img = document.querySelector(css);
    if (img) {
        console.log('Element found:', img);
        if (img.tagName.toLowerCase() === 'img') {
            img.click();
            console.log('Image clicked');
        } else {
            console.error('Selected element is not an image');
        }
        auto_process();
    } else {
        console.error('Element not found for selector:', css);
    }
}

function clickNextButton() {
    // 选择NextSlideBtn按钮
    let SlideBtn = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > div > div > div > div > div > div > button');
    const ButtonType = SlideBtn.getAttribute('aria-label')
    if (ButtonType === "Previous slide") {
        let NextSlideBtn = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > div > div > div > div > div:nth-child(2) > div > button');
        if (NextSlideBtn) {
            NextSlideBtn.click();
            // console.log('Button clicked, waiting...'); // 日志信息用于调试
            setTimeout(clickNextButton, wait_time); // 等待wait_time毫秒后再次调用clickNextButton
        } else {
            // console.log('Button no longer exists'); // 日志信息用于调试
        }
    } else {
        // 如果按钮存在，点击它并等待，然后再次检查按钮是否存在
        if (SlideBtn) {
            SlideBtn.click();
            // console.log('Button clicked, waiting...'); // 日志信息用于调试
            setTimeout(clickNextButton, wait_time); // 等待wait_time毫秒后再次调用clickNextButton
        } else {
            // console.log('Button no longer exists'); // 日志信息用于调试
        }
    }
}

// 定义一个函数auto_process, 用于顺序执行一系列操作并延迟一段时间
function auto_process() {
    // 获取CommentsBtn和closeBtn
    const CommentsBtn = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div:nth-child(2) > div:nth-child(2) > div > div > div:nth-child(3) > button');
    const closeBtn = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > div > button');

    // 点击CommentsBtn
    setTimeout(() => {
        // Check if the Comments button exists
        if (CommentsBtn) {
            // Get the aria-label attribute
            const ariaLabel = CommentsBtn.getAttribute('aria-label');
            if (ariaLabel === "View post") { // 如果评论未展开, 则展开评论
                CommentsBtn.click();
            } else if (ariaLabel === "Hide post") {
                // 如果评论已展开, 则直接进行下一步
            } else {
                console.log('aria-label has a different value:', ariaLabel);
            }
            setTimeout(() => {
                let SlideOrReplyBtn = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > div > div > div > div > div > div > button');
                const SlideOrReplyBtn_ariaLabel = SlideOrReplyBtn.getAttribute('aria-label');
                // 初始化一个空数组，用于保存符合条件的img的src
                const images = [];
                // 如果只有一张图片或只有一个视频
                if (SlideOrReplyBtn_ariaLabel.includes('Reply')) {
                    setTimeout(() => {
                        let img_area = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div');
                        const imgNodes = img_area.querySelectorAll('img');
                        if (imgNodes.length === 0) {
                            // 如果没有找到图片, 则判断是否是视频
                            const vedioNodes = img_area.querySelectorAll('video');
                            if (vedioNodes.length === 0) {
                                // 如果也没找到视频
                                console.log('No image and video found.');
                            } else {
                                console.log(vedioNodes[0].querySelector('source').src);
                            }
                            closeBtn.click();
                            return;
                        } else {
                            // 如果找到一张图片, 则直接下载
                            const img = imgNodes[0];
                            if (img.alt === "Image") {
                                images.push(img.src);
                            } else {
                                console.error('list_item not found');
                            }
                            // 输出数组以确认结果
                            console.log(images);
                        }

                        // 等待一段时间后, 获取文字内容和日期信息
                        setTimeout(() => {
                            // 获取内容信息, 保存至content变量中
                            let text_area_1 = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(1) > div > div > article > div > div > div:nth-child(3) > div:nth-child(1) > div > div');
                            // 对于text区域有链接的情况
                            let text_area_2 = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(3) > div > div > article > div > div > div:nth-child(3) > div:nth-child(1) > div > div');
                            // 对于text区域有图片的情况
                            let text_area_3 = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(1) > div > div > article > div > div > div > div:nth-child(2) > div:nth-child(2)');
                            let text_area_4 = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(2) > div > div > article > div > div > div:nth-child(3) > div:nth-child(1)');
                            const text_areas = [text_area_1, text_area_2, text_area_3, text_area_4];
                            let text_area = null;
                            for (let i = 0; i < text_areas.length; i++) {
                                if (text_areas[i] !== null) {
                                    text_area = text_areas[i];
                                    break;
                                }
                            }

                            // 初始化一个空数组，用于保存span节点的文本内容
                            let contentArray = [];
                            // 获取目标节点下所有的span节点
                            if (text_area) {
                                const spanNodes = text_area.querySelectorAll('span');
                                // 遍历所有span节点，提取文本内容并过滤掉图片、emoji和role="link"的a节点下的span
                                spanNodes.forEach(span => {
                                    // 检查span节点是否在具有role="link"属性的a节点内
                                    if (span.closest('a[role="link"]')) {
                                        return; // 跳过role="link"的a节点内的span
                                    }

                                    const textContent = span.textContent || span.innerText;
                                    if (textContent) {
                                        // 使用正则表达式去除emoji表情，并将换行符替换为空格
                                        const cleanText = textContent
                                            .replace(/([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDE4F]|\uD83D[\uDE80-\uDEFF]|\uD83E[\uDD00-\uDDFF])/g, '')
                                            .replace(/\n/g, ' ');
                                        contentArray.push(cleanText.trim());
                                    }
                                });
                                // 拼接数组中的所有文本内容，用空格隔开
                                content = contentArray.join(' ');
                            } else {
                                content = '';
                            }
                            // 输出结果
                            console.log(content);

                            // 获取日期信息, 保存至date变量中
                            let article = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(1) > div > div > article');
                            timeNode = article.querySelector('time');
                            if (timeNode === null) {
                                // 如果存在This Post was deleted by the Post author. 则date在别处
                                let article = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(2) > div > div > article');
                                timeNode = article.querySelector('time');
                            }
                            let date = '';
                            if (timeNode) {
                                const datetime = timeNode.getAttribute('datetime');
                                if (datetime) {
                                    const dateObject = new Date(datetime);
                                    const year = dateObject.getFullYear();
                                    const month = String(dateObject.getMonth() + 1).padStart(2, '0'); // 月份从0开始，需要加1
                                    const day = String(dateObject.getDate()).padStart(2, '0');
                                    date = `${year}-${month}-${day}`;
                                }
                            }
                            // 输出结果
                            console.log(date);

                            setTimeout(() => {
                                // 等待一段时间后, 下载所有图片
                                download_imgs(images, date, content);
                                setTimeout(() => {
                                    // 等待一段时间后, 点击关闭按钮
                                    closeBtn.click();
                                }, wait_time);
                            }, wait_time);
                        }, wait_time);

                    }, wait_time);
                } else { // 如果有多张图片或多个视频, 等待一段时间后, 翻动所有页面, 然后下载
                    clickNextButton();
                    setTimeout(() => {
                        // 等待一段时间后, 获取图片信息
                        setTimeout(() => {
                            let list_item = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > div > div > div > div > ul');
                            // 确认list_item存在
                            if (list_item) {
                                // 获取目标节点下所有的img节点
                                const imgNodes = list_item.querySelectorAll('img');
                                // 遍历所有img节点，检查其alt属性是否为"Image"
                                imgNodes.forEach(img => {
                                    if (img.alt === "Image") {
                                        images.push(img.src);
                                    }
                                });
                            } else {
                                console.error('list_item not found');
                            }
                            // 输出数组以确认结果
                            console.log(images);

                            // 等待一段时间后, 获取文字内容和日期信息
                            setTimeout(() => {
                                // 获取内容信息, 保存至content变量中
                                let text_area_1 = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(1) > div > div > article > div > div > div:nth-child(3) > div:nth-child(1) > div > div');
                                // 对于text区域有链接的情况
                                let text_area_2 = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(3) > div > div > article > div > div > div:nth-child(3) > div:nth-child(1) > div > div');
                                // 对于text区域有图片的情况
                                let text_area_3 = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(1) > div > div > article > div > div > div > div:nth-child(2) > div:nth-child(2)');
                                let text_area_4 = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(2) > div > div > article > div > div > div:nth-child(3) > div:nth-child(1)');
                                const text_areas = [text_area_1, text_area_2, text_area_3, text_area_4];
                                let text_area = null;
                                for (let i = 0; i < text_areas.length; i++) {
                                    if (text_areas[i] !== null) {
                                        text_area = text_areas[i];
                                        break;
                                    }
                                }

                                // 初始化一个空数组，用于保存span节点的文本内容
                                let contentArray = [];
                                // 获取目标节点下所有的span节点
                                if (text_area) {
                                    const spanNodes = text_area.querySelectorAll('span');
                                    // 遍历所有span节点，提取文本内容并过滤掉图片、emoji和role="link"的a节点下的span
                                    spanNodes.forEach(span => {
                                        // 检查span节点是否在具有role="link"属性的a节点内
                                        if (span.closest('a[role="link"]')) {
                                            return; // 跳过role="link"的a节点内的span
                                        }

                                        const textContent = span.textContent || span.innerText;
                                        if (textContent) {
                                            // 使用正则表达式去除emoji表情，并将换行符替换为空格
                                            const cleanText = textContent
                                                .replace(/([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDE4F]|\uD83D[\uDE80-\uDEFF]|\uD83E[\uDD00-\uDDFF])/g, '')
                                                .replace(/\n/g, ' ');
                                            contentArray.push(cleanText.trim());
                                        }
                                    });
                                    // 拼接数组中的所有文本内容，用空格隔开
                                    content = contentArray.join(' ');
                                } else {
                                    content = '';
                                }
                                // 输出结果
                                console.log(content);

                                // 获取日期信息, 保存至date变量中
                                let article = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(1) > div > div > article');
                                timeNode = article.querySelector('time');
                                if (timeNode === null) {
                                    // 如果存在This Post was deleted by the Post author. 则date在别处
                                    let article = document.querySelector('#layers > div:nth-child(2) > div > div > div > div > div > div > div > div > div > section > div > div > div:nth-child(2) > div > div > article');
                                    timeNode = article.querySelector('time');
                                }
                                let date = '';
                                if (timeNode) {
                                    const datetime = timeNode.getAttribute('datetime');
                                    if (datetime) {
                                        const dateObject = new Date(datetime);
                                        const year = dateObject.getFullYear();
                                        const month = String(dateObject.getMonth() + 1).padStart(2, '0'); // 月份从0开始，需要加1
                                        const day = String(dateObject.getDate()).padStart(2, '0');
                                        date = `${year}-${month}-${day}`;
                                    }
                                }
                                // 输出结果
                                console.log(date);

                                setTimeout(() => {
                                    // 等待一段时间后, 下载所有图片
                                    download_imgs(images, date, content);
                                    setTimeout(() => {
                                        // 等待一段时间后, 点击关闭按钮
                                        closeBtn.click();
                                    }, wait_time);
                                }, wait_time);
                            }, wait_time);
                        }, wait_time);
                    }, wait_time);
                }
            }, wait_time);
        } else {
            console.log('Comments button not found');
        }
    }, wait_time);
}

// 监听右键点击事件，并保存被点击的元素
document.addEventListener('contextmenu', function (event) {
    window.rightClickedElement = event.target;
}, true);

// 监听来自后台脚本的消息
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.from === 'background' && msg.subject === 'getimgs') {
        const element = window.rightClickedElement;
        // console.log('Right clicked element:', element);
        // auto_download(selector);
        element.click();
        setTimeout(() => {
            auto_process();
        }, wait_time);
        sendResponse(selector);
    }
});