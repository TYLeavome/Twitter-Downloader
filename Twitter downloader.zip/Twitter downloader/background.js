chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "twitterDownloader",
    title: "Twitter downloader",
    contexts: ["all"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "twitterDownloader") {
    chrome.tabs.sendMessage(tab.id, {
      from: "background",
      subject: "getimgs"
    });
  }
});